MortarShield is basically a dual stepper motor driver with integrated power supply and GPS module. 
Designed as part of bigger hobby project: https://github.com/kwahoo2/Mortar
The goal was to "electrify" a dobsonian-mounted telescope and connect it with Stellarium.

Created by twizzt3r@gmail.com